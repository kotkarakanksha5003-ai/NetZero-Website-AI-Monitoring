from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime, timedelta
import random
import statistics

app = FastAPI(title="Smart Campus Net-Zero Model API", version="1.1")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------
# Net-Zero calculator
# -------------------------
class Inputs(BaseModel):
    campus_name: str = Field(default="Example University")

    baseline_annual_kwh: float = Field(default=3_000_000, ge=0)
    baseline_peak_kw: float = Field(default=1_200, ge=0)

    grid_emission_factor_kg_per_kwh: float = Field(default=0.7, ge=0)
    tariff_inr_per_kwh: float = Field(default=8.0, ge=0)

    rooftop_area_m2: float = Field(default=12_000, ge=0)
    solar_power_density_kw_per_m2: float = Field(default=0.18, ge=0)
    solar_specific_yield_kwh_per_kw_year: float = Field(default=1500, ge=0)

    solar_capex_inr_per_kw: float = Field(default=45_000, ge=0)
    solar_om_percent_per_year: float = Field(default=1.5, ge=0)

    efficiency_target_fraction: float = Field(default=0.20, ge=0, le=0.8)
    efficiency_capex_inr: float = Field(default=30_000_000, ge=0)


def compute(inputs: Inputs) -> dict:
    post_eff_kwh = inputs.baseline_annual_kwh * (1 - inputs.efficiency_target_fraction)

    solar_kw = inputs.rooftop_area_m2 * inputs.solar_power_density_kw_per_m2
    solar_kwh = solar_kw * inputs.solar_specific_yield_kwh_per_kw_year

    net_grid_kwh = max(0.0, post_eff_kwh - solar_kwh)
    renewable_fraction = min(1.0, solar_kwh / post_eff_kwh) if post_eff_kwh > 0 else 0.0

    baseline_tco2 = inputs.baseline_annual_kwh * inputs.grid_emission_factor_kg_per_kwh / 1000
    post_tco2 = net_grid_kwh * inputs.grid_emission_factor_kg_per_kwh / 1000
    emissions_reduced_tco2 = baseline_tco2 - post_tco2

    baseline_bill = inputs.baseline_annual_kwh * inputs.tariff_inr_per_kwh
    post_bill = net_grid_kwh * inputs.tariff_inr_per_kwh
    annual_bill_savings = baseline_bill - post_bill

    solar_capex = solar_kw * inputs.solar_capex_inr_per_kw
    solar_om = solar_capex * (inputs.solar_om_percent_per_year / 100)
    total_capex = solar_capex + inputs.efficiency_capex_inr

    net_annual_savings = annual_bill_savings - solar_om
    simple_payback_years = (total_capex / net_annual_savings) if net_annual_savings > 0 else None

    net_zero_achieved = solar_kwh >= post_eff_kwh

    return {
        "campus_name": inputs.campus_name,
        "baseline": {
            "annual_kwh": inputs.baseline_annual_kwh,
            "peak_kw": inputs.baseline_peak_kw,
            "tco2": baseline_tco2,
            "annual_bill_inr": baseline_bill,
        },
        "post_project": {
            "post_efficiency_kwh": post_eff_kwh,
            "solar_kw": solar_kw,
            "solar_kwh": solar_kwh,
            "net_grid_kwh": net_grid_kwh,
            "renewable_fraction": renewable_fraction,
            "tco2": post_tco2,
            "annual_bill_inr": post_bill,
        },
        "impact": {
            "emissions_reduced_tco2_per_year": emissions_reduced_tco2,
            "annual_bill_savings_inr": annual_bill_savings,
        },
        "economics": {
            "solar_capex_inr": solar_capex,
            "efficiency_capex_inr": inputs.efficiency_capex_inr,
            "total_capex_inr": total_capex,
            "solar_om_inr_per_year": solar_om,
            "net_annual_savings_inr": net_annual_savings,
            "simple_payback_years": simple_payback_years,
        },
        "net_zero": {
            "achieved": net_zero_achieved,
            "generation_ge_consumption": net_zero_achieved,
        }
    }

# -------------------------
# AI Monitoring (lightweight)
# -------------------------
class MeterPoint(BaseModel):
    ts: datetime
    kw: float = Field(ge=0)

class MonitorConfig(BaseModel):
    # Simple, explainable “AI” rules
    zscore_threshold: float = Field(default=3.0, ge=1.0, le=10.0)
    night_start_hour: int = Field(default=22, ge=0, le=23)
    night_end_hour: int = Field(default=6, ge=0, le=23)
    night_kw_threshold: float = Field(default=0.0, ge=0.0)
    peak_kw_threshold: Optional[float] = Field(default=None, ge=0.0)

class MonitorRequest(BaseModel):
    points: List[MeterPoint]
    config: MonitorConfig = MonitorConfig()


def _is_night(hour: int, start: int, end: int) -> bool:
    # Night window may wrap across midnight
    if start <= end:
        return start <= hour < end
    return hour >= start or hour < end


def analyze(points: List[MeterPoint], config: MonitorConfig) -> dict:
    # Sort points
    points = sorted(points, key=lambda p: p.ts)
    values = [p.kw for p in points]

    anomalies = []

    if len(values) < 6:
        return {
            "anomalies": anomalies,
            "summary": {
                "message": "Need at least 6 points for anomaly detection.",
                "count": 0,
            }
        }

    mean = statistics.mean(values)
    stdev = statistics.pstdev(values) or 1e-9

    # Z-score spikes
    for p in points:
        z = (p.kw - mean) / stdev
        if z >= config.zscore_threshold:
            anomalies.append({
                "ts": p.ts.isoformat(),
                "kw": p.kw,
                "type": "spike",
                "score": round(z, 2),
                "message": f"Spike detected (z={z:.2f})"
            })

    # Night-time base-load check
    for p in points:
        if _is_night(p.ts.hour, config.night_start_hour, config.night_end_hour) and p.kw > config.night_kw_threshold:
            anomalies.append({
                "ts": p.ts.isoformat(),
                "kw": p.kw,
                "type": "night_load",
                "score": None,
                "message": f"High night-time load (> {config.night_kw_threshold} kW)"
            })

    # Peak threshold
    if config.peak_kw_threshold is not None:
        for p in points:
            if p.kw > config.peak_kw_threshold:
                anomalies.append({
                    "ts": p.ts.isoformat(),
                    "kw": p.kw,
                    "type": "peak_exceed",
                    "score": None,
                    "message": f"Peak exceeded (> {config.peak_kw_threshold} kW)"
                })

    # Deduplicate (same ts+type)
    seen = set()
    uniq = []
    for a in anomalies:
        key = (a["ts"], a["type"])
        if key not in seen:
            seen.add(key)
            uniq.append(a)

    uniq.sort(key=lambda x: x["ts"])

    return {
        "anomalies": uniq,
        "summary": {
            "count": len(uniq),
            "mean_kw": mean,
            "stdev_kw": stdev,
            "zscore_threshold": config.zscore_threshold,
        }
    }


class SimulateRequest(BaseModel):
    days: int = Field(default=7, ge=1, le=30)
    base_kw: float = Field(default=250.0, ge=0)
    day_kw: float = Field(default=550.0, ge=0)
    noise_kw: float = Field(default=30.0, ge=0)
    inject_spikes: int = Field(default=4, ge=0, le=50)


def simulate(req: SimulateRequest) -> List[MeterPoint]:
    # Hourly synthetic data with realistic day/night pattern
    start = datetime.now().replace(minute=0, second=0, microsecond=0) - timedelta(days=req.days)
    points = []
    hours = req.days * 24
    for i in range(hours):
        ts = start + timedelta(hours=i)
        hour = ts.hour
        # simple profile: higher in 9-18, medium evening, low night
        if 9 <= hour <= 18:
            base = req.day_kw
        elif 19 <= hour <= 22:
            base = (req.base_kw + req.day_kw) / 2
        else:
            base = req.base_kw

        kw = max(0.0, random.gauss(base, req.noise_kw))
        points.append(MeterPoint(ts=ts, kw=kw))

    # Inject spikes
    idxs = random.sample(range(hours), k=min(req.inject_spikes, hours)) if req.inject_spikes else []
    for idx in idxs:
        points[idx].kw *= random.uniform(1.8, 3.2)

    return points


@app.get("/")
def root():
    return {"status": "ok", "message": "Net-Zero API is running"}

@app.post("/compute")
def compute_endpoint(payload: Inputs):
    return compute(payload)

@app.post("/monitor/analyze")
def analyze_endpoint(payload: MonitorRequest):
    return analyze(payload.points, payload.config)

@app.post("/monitor/simulate")
def simulate_endpoint(payload: SimulateRequest):
    pts = simulate(payload)
    return {"points": [{"ts": p.ts.isoformat(), "kw": p.kw} for p in pts]}
