# Smart Campus Net‑Zero — Website + API (with AI Monitoring)

This project is a **working website** + **backend API** for the Smart Campus Net‑Zero hackathon theme.

## Features

### 1) Net‑Zero Calculator
- Efficiency reduction → post-demand
- Space-limited solar sizing → solar generation
- Renewable fraction, grid import, CO₂ reduction
- Costs: CAPEX, O&M, annual savings, payback

### 2) AI Monitoring (Explainable Anomaly Detection)
- Paste hourly smart-meter data as CSV (`ts,kw`)
- Detect:
  - **Spikes** using z-score
  - **Night-time base load** above threshold
  - **Peak exceed** above peak threshold
- Simulate 7-day data to demo instantly

---

## Run locally

### Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

API docs: http://127.0.0.1:8000/docs

### Frontend
Open `frontend/index.html` in your browser.
- Keep API URL: `http://127.0.0.1:8000`
- Use tabs: **Calculator** and **AI Monitoring**

---

## CSV format
Example:
```
2026-02-20T10:00:00,410
2026-02-20T11:00:00,430
```

---

## Deploy (optional)
- Backend: Azure Web Apps / Render / Fly
- Frontend: GitHub Pages / Netlify / Vercel

> If hosting frontend separately, update the API URL field to your deployed backend URL.
